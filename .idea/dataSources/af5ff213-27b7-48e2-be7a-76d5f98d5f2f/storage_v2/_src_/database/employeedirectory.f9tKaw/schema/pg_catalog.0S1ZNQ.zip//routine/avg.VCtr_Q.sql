create function avg(bigint) returns numeric
	language internal
as $$
aggregate_dummy
$$;

comment on function avg(int2) is 'the average (arithmetic mean) as numeric of all smallint values';

