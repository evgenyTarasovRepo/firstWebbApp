create function circle_mul_pt(circle, point) returns circle
	language internal
as $$
circle_mul_pt
$$;

comment on function circle_mul_pt(circle, point) is 'implementation of * operator';

