create function cash_le(money, money) returns boolean
	language internal
as $$
cash_le
$$;

comment on function cash_le(money, money) is 'implementation of <= operator';

