create function anyenum_out(anyenum) returns cstring
	language internal
as $$
anyenum_out
$$;

comment on function anyenum_out(anyenum) is 'I/O';

