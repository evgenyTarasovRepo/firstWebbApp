create function bpcharcmp(character, character) returns integer
	language internal
as $$
bpcharcmp
$$;

comment on function bpcharcmp(bpchar, bpchar) is 'less-equal-greater';

