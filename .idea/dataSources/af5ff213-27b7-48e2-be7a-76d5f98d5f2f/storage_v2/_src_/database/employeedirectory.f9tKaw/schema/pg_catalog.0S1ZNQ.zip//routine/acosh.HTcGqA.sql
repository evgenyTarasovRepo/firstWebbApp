create function acosh(double precision) returns double precision
	language internal
as $$
dacosh
$$;

comment on function acosh(float8) is 'inverse hyperbolic cosine';

