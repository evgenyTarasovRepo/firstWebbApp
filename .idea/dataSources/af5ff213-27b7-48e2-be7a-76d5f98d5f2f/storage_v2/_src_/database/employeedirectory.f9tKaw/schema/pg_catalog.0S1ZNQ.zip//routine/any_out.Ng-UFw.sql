create function any_out("any") returns cstring
	language internal
as $$
any_out
$$;

comment on function any_out(any) is 'I/O';

