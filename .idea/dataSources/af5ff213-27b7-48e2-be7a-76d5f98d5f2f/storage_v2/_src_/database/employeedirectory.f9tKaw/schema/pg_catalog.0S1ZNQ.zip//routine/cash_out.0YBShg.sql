create function cash_out(money) returns cstring
	language internal
as $$
cash_out
$$;

comment on function cash_out(money) is 'I/O';

