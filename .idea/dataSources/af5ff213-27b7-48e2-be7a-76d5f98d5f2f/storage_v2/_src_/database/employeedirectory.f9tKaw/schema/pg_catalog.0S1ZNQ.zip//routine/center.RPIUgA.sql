create function center(box) returns point
	language internal
as $$
box_center
$$;

comment on function center(circle) is 'center of';

