create function ascii(text) returns integer
	language internal
as $$
ascii
$$;

comment on function ascii(text) is 'convert first char to int4';

