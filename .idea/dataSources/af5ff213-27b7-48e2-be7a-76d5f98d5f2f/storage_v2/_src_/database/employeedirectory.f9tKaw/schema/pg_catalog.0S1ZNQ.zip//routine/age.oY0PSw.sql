create function age(xid) returns integer
	language internal
as $$
xid_age
$$;

comment on function age(xid) is 'age of a transaction ID, in transactions before current transaction';

