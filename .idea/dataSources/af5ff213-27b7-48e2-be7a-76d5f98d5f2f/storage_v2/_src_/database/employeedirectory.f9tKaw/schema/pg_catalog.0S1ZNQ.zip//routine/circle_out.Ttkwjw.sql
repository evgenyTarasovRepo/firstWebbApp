create function circle_out(circle) returns cstring
	language internal
as $$
circle_out
$$;

comment on function circle_out(circle) is 'I/O';

