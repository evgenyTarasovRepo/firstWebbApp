create function close_lb(line, box) returns point
	language internal
as $$
close_lb
$$;

comment on function close_lb(line, box) is 'implementation of ## operator';

