create function circle_gt(circle, circle) returns boolean
	language internal
as $$
circle_gt
$$;

comment on function circle_gt(circle, circle) is 'implementation of > operator';

