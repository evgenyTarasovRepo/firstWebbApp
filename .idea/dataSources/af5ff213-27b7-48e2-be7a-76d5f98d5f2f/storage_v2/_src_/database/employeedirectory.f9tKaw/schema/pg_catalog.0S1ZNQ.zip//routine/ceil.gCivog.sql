create function ceil(double precision) returns double precision
	language internal
as $$
dceil
$$;

comment on function ceil(float8) is 'nearest integer >= value';

