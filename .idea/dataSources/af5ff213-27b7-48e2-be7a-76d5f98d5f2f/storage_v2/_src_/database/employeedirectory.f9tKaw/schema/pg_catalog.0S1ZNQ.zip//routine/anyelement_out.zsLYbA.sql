create function anyelement_out(anyelement) returns cstring
	language internal
as $$
anyelement_out
$$;

comment on function anyelement_out(anyelement) is 'I/O';

