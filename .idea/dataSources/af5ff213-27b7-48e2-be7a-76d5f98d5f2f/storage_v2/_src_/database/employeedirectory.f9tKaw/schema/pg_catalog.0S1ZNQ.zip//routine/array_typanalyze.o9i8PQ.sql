create function array_typanalyze(internal) returns boolean
	language internal
as $$
array_typanalyze
$$;

comment on function array_typanalyze(internal) is 'array typanalyze';

